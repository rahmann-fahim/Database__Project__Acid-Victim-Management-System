# AidNexus – Acid Victims Management System

AidNexus is a secure and comprehensive web‑based system for managing acid attack victims, cases, medical records, appointments, financial aid, notifications, and user roles (Admin & Victim).  
This platform is built with **PHP**, **Oracle Database (XE / 12c / 19c)** and comes with a modern responsive UI.

---

## 🔥 Features

### 🛠️ Core System Modules
**Admin Dashboard**
- Add / edit / remove victim profiles
- Create and manage cases
- Assign doctors and schedule appointments
- Manage medical records and treatment plans
- Upload and manage legal documents & consents
- Track and approve financial aid
- Send notifications to users
- Generate reports and analytics

**Victim Portal**
- View own profile and case details
- Track case status and history
- Access medical records and diagnosis
- View consents and legal documents
- Receive notifications and appointment updates

---

## 📊 Database Overview

The system uses an Oracle relational database with these key tables:

| Table | Purpose |
|-------|---------|
| `users` | System users (Admin, Victims) |
| `roles` | Role definitions |
| `user_role` | User‑Role mapping |
| `victim` | Acid victim personal data |
| `case_t` | Case information |
| `doctor` | Doctor profiles |
| `appointment` | Doctor appointments |
| `consent` | Consent forms |
| `case_note` | Case notes |
| `medical_rec` | Medical records |
| `legal_doc` | Legal documents |
| `financial_aid` | Financial aid records |
| `notification` | System notifications |

---

## 🚀 Getting Started (Local Setup)

### ✔ Requirements
- **XAMPP** (Apache + PHP 8.x)
- **Oracle Database Express Edition (XE)**
- **Oracle Instant Client**
- Browser (Chrome / Edge / Firefox)

---

### 📌 Install Oracle Instant Client (Windows)

1. Download and unzip to:
C:\oraclexe\instantclient_23_0

pgsql
Copy code
2. Add to PATH:
```powershell
setx PATH "C:\oraclexe\instantclient_23_0;%PATH%"
Enable oci8 in php.ini:

ini
Copy code
extension=oci8_12c
Restart Apache.

📌 Import Database
Open SQL*Plus / SQL Developer:

sql
Copy code
@database/schema.sql
Verify your tables:

sql
Copy code
SELECT table_name FROM user_tables;
📌 Configure PHP
Create db.php:

php
Copy code
<?php
$conn = oci_connect('YOUR_ORACLE_USER','YOUR_ORACLE_PASS','localhost/XE');
if (!$conn) {
    $e = oci_error();
    die("Oracle connection failed: " . $e['message']);
}
?>
🧑‍💻 Registration & Login
Users can register via form

Passwords are securely hashed

Admin & Victim roles supported

Successful registration redirects to login

📂 Repository Structure
pgsql
Copy code
AidNexus/
├── assets/                # styles, scripts, images
├── db.php                 # database connection
├── registration.php
├── login.php
├── dashboard.php
├── README.md
└── database/
    └── schema.sql         # Database creation script
💼 Roles & Permissions
Admin
Full control over victims, cases, doctors, appointments, financial aid, reports, notifications, documents.

Victim
Limited access: view own profile, case history, documents, and notifications.

📣 Screenshots
(Add screenshots of pages here if available — registration form, dashboard, etc.)

🧾 Contributing
Fork the repository

Create a new branch

bash
Copy code
git checkout -b feature/your‑feature
Commit your changes

bash
Copy code
git commit -m "Add new feature"
Push to your branch

bash
Copy code
git push origin feature/your‑feature
Open a pull request

🧪 License
This project is licensed under the MIT License — see LICENSE for details.

🔗 Connect
Created by Siam Ahamed
GitHub: https://github.com/siamahamed57
