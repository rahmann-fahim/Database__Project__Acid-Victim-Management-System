<?php
session_start();
include 'db.php';
include 'includes/session_check.php';
include 'includes/role_check.php';
include 'includes/functions.php';

// Require admin access
require_admin();

// Fetch dashboard metrics (ADMIN - System-wide)
$metrics = [
    'total_victims' => 0,
    'open_cases' => 0,
    'pending_approvals' => 0,
    'appointments_next_7_days' => 0
];

// Count total victims
$sql = "SELECT COUNT(*) as cnt FROM victim";
$stmt = oci_parse($conn, $sql);
oci_execute($stmt);
$row = oci_fetch_assoc($stmt);
$metrics['total_victims'] = $row['CNT'];

// Count open cases
$sql = "SELECT COUNT(*) as cnt FROM case_t WHERE case_status = 'Open'";
$stmt = oci_parse($conn, $sql);
oci_execute($stmt);
$row = oci_fetch_assoc($stmt);
$metrics['open_cases'] = $row['CNT'];

// Count pending approvals (In-Process cases)
$sql = "SELECT COUNT(*) as cnt FROM case_t WHERE case_status = 'In-Process'";
$stmt = oci_parse($conn, $sql);
oci_execute($stmt);
$row = oci_fetch_assoc($stmt);
$metrics['pending_approvals'] = $row['CNT'];

// Count appointments in next 7 days
$sql = "SELECT COUNT(*) as cnt FROM appointment WHERE appt_datetime BETWEEN SYSDATE AND SYSDATE + 7";
$stmt = oci_parse($conn, $sql);
oci_execute($stmt);
$row = oci_fetch_assoc($stmt);
$metrics['appointments_next_7_days'] = $row['CNT'];

// Fetch recent activity
$recent_activity = [];
$sql = "SELECT * FROM (
        SELECT case_id, case_type, open_date, case_status 
        FROM case_t 
        ORDER BY open_date DESC
        ) WHERE ROWNUM <= 5";
$stmt = oci_parse($conn, $sql);
oci_execute($stmt);
while ($row = oci_fetch_assoc($stmt)) {
    $recent_activity[] = $row;
}

$user_initials = get_user_initials($username);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AidNexus</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --sidebar-bg: #2C3E50;
            --sidebar-hover: #34495E;
            --primary-green: #4CAF50;
            --bg-page: #F5F5F5;
            --white: #FFFFFF;
            --text-dark: #2C3E50;
            --text-light: #7F8C8D;
            --border: #E0E0E0;
            --shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-page);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: var(--sidebar-bg);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
        }

        .sidebar-header {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header svg {
            width: 24px;
            height: 24px;
        }

        .sidebar-header h1 {
            font-size: 1.25rem;
            font-weight: 700;
        }

        .sidebar-header .admin-badge {
            background-color: var(--primary-green);
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .sidebar-nav {
            flex-grow: 1;
            padding: 20px 0;
        }

        .nav-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.8);
            cursor: pointer;
            transition: all 0.2s;
            font-size: 0.9rem;
        }

        .nav-item:hover {
            background-color: var(--sidebar-hover);
            color: white;
        }

        .nav-item.active {
            background-color: var(--primary-green);
            color: white;
            border-left: 4px solid white;
        }

        .nav-item svg {
            width: 18px;
            height: 18px;
        }

        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            flex-grow: 1;
            padding: 30px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h2 {
            font-size: 1.75rem;
            color: var(--text-dark);
            font-weight: 700;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--text-dark);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        .user-details {
            text-align: right;
        }

        .user-name {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-dark);
        }

        .user-role {
            font-size: 0.75rem;
            color: var(--text-light);
        }

        /* Metrics Grid */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .metric-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            border-left: 4px solid var(--primary-green);
            box-shadow: var(--shadow);
        }

        .metric-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 5px;
        }

        .metric-label {
            font-size: 0.9rem;
            color: var(--text-light);
            font-weight: 500;
        }

        /* Quick Actions */
        .quick-actions {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .quick-actions h3 {
            font-size: 1.25rem;
            color: var(--text-dark);
            margin-bottom: 20px;
            font-weight: 700;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }

        .action-btn {
            padding: 12px 20px;
            border: 1px solid var(--border);
            background: white;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--text-dark);
        }

        .action-btn:hover {
            background: var(--bg-page);
            border-color: var(--primary-green);
        }

        .action-btn svg {
            width: 18px;
            height: 18px;
        }

        /* Recent Activity */
        .recent-activity {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .recent-activity h3 {
            font-size: 1.25rem;
            color: var(--text-dark);
            margin-bottom: 20px;
            font-weight: 700;
        }

        .activity-item {
            padding: 15px 0;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: var(--primary-green);
            margin-top: 6px;
        }

        .activity-content {
            flex-grow: 1;
        }

        .activity-text {
            font-size: 0.9rem;
            color: var(--text-dark);
            margin-bottom: 4px;
        }

        .activity-time {
            font-size: 0.75rem;
            color: var(--text-light);
        }

        @media (max-width: 1200px) {
            .metrics-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .action-buttons {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }
            .main-content {
                margin-left: 200px;
            }
            .metrics-grid {
                grid-template-columns: 1fr;
            }
            .action-buttons {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z"/></svg>
            <h1>AidNexus</h1>
            <span class="admin-badge">ADMIN</span>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-item active">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                <span>Dashboard</span>
            </div>
            <div class="nav-item" onclick="window.location.href='intake.php'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
                <span>Intake (Register)</span>
            </div>
            <div class="nav-item" onclick="window.location.href='all_victims.php'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                <span>All Victims</span>
            </div>
            <div class="nav-item" onclick="window.location.href='all_cases.php'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                <span>All Cases</span>
            </div>
            <div class="nav-item" onclick="window.location.href='all_appointments.php'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                <span>All Appointments</span>
            </div>
            <div class="nav-item" onclick="window.location.href='reports.php'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
                <span>Reports & Analysis</span>
            </div>
        </nav>

        <div class="sidebar-footer">
            <div class="nav-item" onclick="window.location.href='logout.php'">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                <span>Logout</span>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h2>Admin Dashboard</h2>
            <div class="user-info">
                <div class="user-details">
                    <div class="user-name">Admin User</div>
                    <div class="user-role">Role: Administrator</div>
                </div>
                <div class="user-avatar"><?php echo $user_initials; ?></div>
            </div>
        </div>

        <!-- Metrics -->
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-value"><?php echo $metrics['total_victims']; ?></div>
                <div class="metric-label">Total Victims</div>
            </div>
            <div class="metric-card">
                <div class="metric-value"><?php echo $metrics['open_cases']; ?></div>
                <div class="metric-label">Open Cases</div>
            </div>
            <div class="metric-card">
                <div class="metric-value"><?php echo $metrics['pending_approvals']; ?></div>
                <div class="metric-label">Pending Approvals</div>
            </div>
            <div class="metric-card">
                <div class="metric-value"><?php echo $metrics['appointments_next_7_days']; ?></div>
                <div class="metric-label">Appts Next 7 Days</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <h3>Quick Actions</h3>
            <div class="action-buttons">
                <button class="action-btn" onclick="window.location.href='intake.php'">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
                    Intake New Victim
                </button>
                <button class="action-btn" onclick="window.location.href='all_cases.php'">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    Create New Case
                </button>
                <button class="action-btn" onclick="window.location.href='all_appointments.php'">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    Schedule Appt
                </button>
                <button class="action-btn" onclick="window.location.href='reports.php'">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                    Generate Report
                </button>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="recent-activity">
            <h3>Recent Activity</h3>
            <?php if (empty($recent_activity)): ?>
                <p style="color: var(--text-light); padding: 20px 0;">No recent activity.</p>
            <?php else: ?>
                <?php foreach ($recent_activity as $activity): ?>
                    <div class="activity-item">
                        <div class="activity-dot"></div>
                        <div class="activity-content">
                            <div class="activity-text">
                                Case #CS-<?php echo $activity['CASE_ID']; ?>-<?php echo date('Y'); ?> updated (<?php echo htmlspecialchars($activity['CASE_TYPE']); ?>)
                            </div>
                            <div class="activity-time"><?php echo time_ago($activity['OPEN_DATE']); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>
